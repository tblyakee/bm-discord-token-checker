import requests

def check_token(token):
    headers = {
        'Authorization': token.strip(),
    }

    response = requests.get('https://discord.com/api/v9/users/@me', headers=headers)

    if response.status_code == 200:
        print(f"Token '{token.strip()}' is VALID.")
        return True
    else:
        print(f"Token '{token.strip()}' is INVALID.")
        return False

if __name__ == "__main__":
    input_file = 'tokens.txt'

    try:
        with open(input_file, 'r') as file:
            tokens = file.readlines()

        for token in tokens:
            check_token(token)

    except FileNotFoundError:
        print(f"Error: File '{input_file}' not found.")
    except Exception as e:
        print(f"An error occurred: {str(e)}")
